package com.i.myinfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.AndroidVersionViewHolder> {

    private List<AndroidVersion> androidVersionsList;
    private Context context;
    private ItemClickListener itemClickListener;

    public AndroidVersionAdapter(List<AndroidVersion> androidVersionsList, Context context) {
        this.androidVersionsList = androidVersionsList;
        this.context = context;
    }


    @NonNull
    @Override
    public AndroidVersionAdapter.AndroidVersionViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.layout_android_version, viewGroup, false);
        return new AndroidVersionAdapter.AndroidVersionViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(AndroidVersionAdapter.AndroidVersionViewHolder holder, int position) {
        holder.versionIcon.setImageResource(androidVersionsList.get(position).getIcon());
        holder.versionName.setText(androidVersionsList.get(position).getName());
        holder.releaseDate.setText(androidVersionsList.get(position).getReleaseDate());
    }

    @Override
    public int getItemCount() {
        return androidVersionsList.size();
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public class AndroidVersionViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView versionIcon;
        TextView versionName, releaseDate;

        public AndroidVersionViewHolder(View view) {
            super(view);
            versionIcon = view.findViewById(R.id.versionIcon);
            versionName = view.findViewById(R.id.versionName);
            releaseDate = view.findViewById(R.id.versionDate);
        }

        @Override
        public void onClick(View view) {
            if (itemClickListener != null) {
                itemClickListener.onClick(view, getAdapterPosition());
            }
        }
    }
}
