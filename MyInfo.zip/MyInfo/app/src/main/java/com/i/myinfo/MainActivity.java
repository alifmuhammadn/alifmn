package com.i.myinfo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.InputFilter;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ItemClickListener  {

    int[] IconsList = {R.drawable.buahpisang, R.drawable.buahsirsak, R.drawable.buahpir, R.drawable.buahmanggis, R.drawable.buahmangga, R.drawable.buahjeruk, R.drawable.buahkelengkeng, R.drawable.buahdurian, R.drawable.buahapel, R.drawable.buahalpukat };

    String[] nameList = {"buahpisang", "buahsirsak", "buahpir", "buahmanggis", "buahmangga", "buahjeruk", "buahkelengkeng", "buahdurian", "buahapel", "buahalpukat"};

    String[] dataList = {"Pisang, punya banyak serat, antioksidan dan vitamin yang baik bagi tubuh,memiliki nutrisi yang menyeimbangkan gula darah,meningkatkan kesehatan pencernaan,membantu menurunkan berat badan",
            "Sirsak,Meningkatkan daya tahan tubuh,Meredakan peradangan,Melancarkan pencernaan,Melawan infeksi,Mencegah pertumbuhan sel kanker",
            "Pir,Mengandung antioksidan. Pir memiliki efek antioksidan glutathione dan anti kanker yang baik untuk kesehatan tubuh,Sumber vitamin C tinggi,Baik untuk kulit,Mengandung banyak serat baik,Mencegah sembelit,Membantu menjaga kesehatan tulang",
            "Manggis,Meningkatkan Sistem Kekebalan Tubuh. Dalam buah manggis terdapat beberapa kandungan nutrisi yang cukup kaya berupa xanthone, mineral, vitamin,Mempercepat Penyembuhan,Mengobati Diare dan Disentri,Mengatasi Masalah Mentruasi,Mengontrol Diabetes,Menurunkan Berat Badan",
            "Mangga,Meningkatkan kekebalan tubuh,Mengatasi masalah pencernaan,Menyembuhkan penyakit anemia,Menurunkan kadar kolesterol,Mengurangi risiko terkena penyakit jantung",
            "Jeruk,Melancarkan Pencernaan,Sumber serat yang sangat baik larut dan tidak larut ada pada jeruk,Mengatur Tekanan Darah Tinggi,Mencegah Kanker,Meningkatkan Kekebalan Tubuh,Memurnikan Darah,Memperkuat Gigi,Memperkuat tulang,Sumber Vitamin C",
            "Kelengkeng,Menjaga Kesehatan Jantung,Buah kelengkeng dipercaya mampu menjaga kesehatan jantung dan menyehatkan pembuluh darah karena mengandung vitamin C cukup tinggi,Mencegah Penyakit Batu Ginjal,Mengatasi Diabetes,Meningkatkan Kesehatan Mata",
            "Durian,Meredakan anemia,Membantu menjaga kesehatan tulang,membantu meringankan depresi dan meningkatkan kualitas tidur,Melawan kanker,Membantu sistem pencernaan,Meningkatkan kesuburan dan menyembuhkan PCOS,Mencegah penuaan dini",
            "Apel,Cegah Penyakit Stroke,Manfaat buah apel yang pertama adalah mencegah penyakit stroke,Bantu Menurunkan Berat Badan. Apel memiliki kandungan mineral dan serat cukup tinggi,Meningkatkan Kinerja Otak",
            "Alpukat,Mencegah Resiko Kanker,Kanker memang diketahui termasuk salah satu penyakit mematikan di dunia,Mencegah Sakit Jantung,Menjaga Kesehatan Mata,Melancarkan Pencernaan,Mencegah Depresi"};

    RecyclerView recyclerView;
    AndroidVersionAdapter androidVersionAdapter;
    List<AndroidVersion> androidVersionList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView =findViewById(R.id.recyclerView);

        androidVersionAdapter = new AndroidVersionAdapter(androidVersionList, MainActivity.this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(androidVersionAdapter);
        androidVersionAdapter.setClickListener(this);
        androidVersionAdapter.notifyDataSetChanged();

        // Filling our recycler view List
        for ( int i=0; i<IconsList.length; i++ ){
            String name = nameList[i];
            String date = dataList[i];
            int icon = IconsList[i];

            AndroidVersion androidVersion = new AndroidVersion(i, icon, name, date);
            androidVersionList.add(androidVersion);
        }
    }

    @Override
    public void onClick(View view, int position) {
        int id = androidVersionList.get(position).getId();
        String name = androidVersionList.get(position).getName();
        Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
    }
}
